# Plantilla de estimación asistida por IA
## Entregable de planificación — Tema 3

> El equipo completa esta plantilla para una historia de usuario del proyecto. La idea no es
> que la IA arme el cronograma, sino usarla para **no olvidar tareas** y después **criticar**
> lo que devuelve con lo que solo el equipo sabe. Regla del tramo: la IA es buena listando lo
> que falta y mala prediciendo cuánto cuesta. Se le pide **inventario, no cronograma**.

**Equipo (nombres):**

**Historia de usuario que se estima:**
*(Formato "Como &lt;rol&gt; quiero &lt;objetivo&gt; para &lt;beneficio&gt;".)*

---

## 1. Descomposición en tareas (la IA ayuda de verdad)

Se le pide a la IA que descomponga la historia en tareas técnicas. Devuelve una lista razonable
y, sobre todo, las tareas que el equipo suele olvidar: la migración de la base, el manejo de
errores, el texto de los correos, las pruebas. El equipo agrega o quita según su contexto.

## 2. Tamaño relativo, no horas (donde no hay que creerle)

Cada tarea se mide **contra una tarea base**, no en horas absolutas. Se elige una tarea
pequeña y clara como referencia (talla **S**) y se compara el resto contra ella. Si una tarea
parece el doble de grande que la base, es **M**; si es varias veces más grande o tiene partes
sin resolver, es **L**. Lo que importa es la proporción entre tareas, no el número.

- **S** — tarea chica y entendida; sirve de referencia.
- **M** — se siente como dos o tres veces la base.
- **L** — varias veces la base, o con partes que el equipo todavía no sabe cómo resolver.

## 3. Dependencias (la IA ayuda a medias)

La IA acierta en las dependencias **estructurales** (la autenticación va antes que el perfil).
Lo que no sabe es cómo está armado **este** equipo: quién entra cuándo, qué se está esperando
de un tercero, qué licencia todavía no se compró. Esa columna la corrige el equipo.

---

## Tabla de estimación

| # | Tarea | Depende de (#) | Tamaño relativo (S/M/L) | Crítica del equipo (lo que la IA no puede saber) |
|---|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |
| 4 |  |  |  |  |
| 5 |  |  |  |  |

*(Se agregan filas según haga falta. La tarea de referencia (talla S) se marca en la columna
de tamaño.)*

---

## 4. Cierre: tres a cinco líneas

El equipo escribe un párrafo corto que responda:

- ¿Qué tarea agregó el equipo que la IA no había puesto, o cuál quitó por no aplicar?
- ¿Qué dependencia corrigió el equipo con información que la IA no tenía?
- ¿Cuál es la tarea más grande (talla L) y por qué el equipo todavía no sabe cuánto cuesta?

> **Referencia rápida.**
> - **estimación relativa:** comparar el tamaño de una tarea contra otra en vez de predecir horas absolutas.
> - **dependencia:** una tarea que no puede empezar hasta que otra termine.
> - **historia de usuario:** una necesidad escrita desde la óptica del usuario, en formato "Como &lt;rol&gt; quiero &lt;objetivo&gt; para &lt;beneficio&gt;".
