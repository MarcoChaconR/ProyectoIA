# Galería de requisitos generados por IA — para criticar en clase

> La IA convirtió esta idea en requisitos. Todo se ve bien escrito. La tarea no es
> reescribirlo desde cero: es **marcar qué está flojo y por qué**, del mismo modo en
> que después se critica una arquitectura generada.

**Idea de partida:** *"una app para reservar citas en un consultorio dental"*

---

## 1. Historias de usuario (como las devolvió la IA)

1. Como paciente quiero reservar una cita para mejorar mi experiencia con la clínica.
2. Como usuario quiero una interfaz intuitiva para navegar fácilmente por la aplicación.
3. Como paciente quiero recibir un recordatorio el día anterior para no olvidar la cita.
4. Como recepcionista quiero gestionar las citas para optimizar el flujo de trabajo.
5. Como administrador quiero un panel de control moderno para tomar mejores decisiones.

## 2. Supuestos que dice estar haciendo

- Asumo que la aplicación tendrá una base de datos.
- Asumo que los usuarios tendrán acceso a internet.
- Asumo que se usará un framework web moderno.

## 3. Preguntas que propone para el cliente

1. ¿Qué colores prefiere para la interfaz?
2. ¿La aplicación debe ser rápida y fácil de usar?
3. ¿Prefiere una aplicación web o móvil?

---

## Su tarea (en equipo, con IA)

De las tres listas de arriba, marquen lo que está flojo y arréglenlo:

- **Historias de usuario:** ¿cuáles tienen un beneficio de verdad y cuáles un relleno
  genérico? Reescriban las flojas para que el beneficio sea el motivo real.
- **Supuestos:** ¿cuáles son supuestos que de verdad podrían ser falsos y cambiar el
  producto, y cuáles son obviedades que no aportan? Escriban dos supuestos que sí importen.
- **Preguntas:** ¿cuáles cambiarían el diseño del sistema si la respuesta fuera distinta, y
  cuáles no cambian nada? Escriban tres preguntas cuya respuesta mueva el modelo de datos o
  la arquitectura.

Entreguen la versión corregida de las tres listas. Lo que se evalúa es la corrección, no la
lista original.
