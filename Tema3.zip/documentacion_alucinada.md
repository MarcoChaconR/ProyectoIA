# Documentación generada por IA — ¿corresponde al código?

> A la IA se le pidió documentar la API de reservas a partir del código. Devolvió el documento
> de abajo. Se ve completo y profesional. La tarea es **verificar cada afirmación contra el
> código real**, que está justo debajo, y marcar lo que el documento inventó.

---

## Código real (lo único que existe)

```python
# api_reservas.py — el código que de verdad está escrito
from flask import Flask, request, jsonify

app = Flask(__name__)
reservas = []

@app.route("/reservas", methods=["POST"])
def crear_reserva():
    datos = request.get_json()
    reservas.append({"cancha": datos["cancha"], "hora": datos["hora"]})
    return jsonify({"estado": "creada"}), 201

@app.route("/reservas", methods=["GET"])
def listar_reservas():
    return jsonify(reservas), 200
```

Son **dos endpoints**: crear una reserva y listar todas. No hay nada más.

---

## Documentación que devolvió la IA

> ### API de Reservas — Referencia
>
> **`POST /reservas`** — Crea una nueva reserva.
> Parámetros: `cancha` (string), `hora` (string), `usuario_id` (int), `metodo_pago` (string).
> Respuestas: `201` reserva creada · `400` datos inválidos · `409` horario ya ocupado.
>
> **`GET /reservas`** — Lista las reservas del usuario autenticado.
> Parámetros de consulta: `fecha` (filtra por día), `estado` (confirmada/cancelada).
> Respuestas: `200` lista de reservas · `401` no autenticado.
>
> **`GET /reservas/{id}`** — Devuelve una reserva por su identificador.
> Respuestas: `200` reserva encontrada · `404` no existe.
>
> **`DELETE /reservas/{id}`** — Cancela una reserva.
> Respuestas: `204` cancelada · `403` sin permiso para cancelar esta reserva.
>
> **Autenticación:** todas las llamadas requieren un token JWT en la cabecera `Authorization`.

---

## Su tarea (en equipo, con IA)

Marquen, línea por línea, qué del documento corresponde al código y qué se inventó. Luego
respondan: **¿por qué es peligroso este documento?**

Entreguen la lista de lo que el documento afirma y que el código no respalda.
